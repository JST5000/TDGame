/**
 * 
 */
/** This package is designed to hold the objects that directly interact with the player
 * such as the enemies, turrets and other necessary objects.
 * @author Jackson
 *
 */
package playerObjects;