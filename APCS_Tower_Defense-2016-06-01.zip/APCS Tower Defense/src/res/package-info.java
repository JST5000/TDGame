/**
 * 
 */
/** This holds resources
 * @author Jackson
 *
 */
package res;